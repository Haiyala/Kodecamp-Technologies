<?php
			if (isset($_POST['submit'])) {
				$name = $_POST['name'];
				$phone = $_POST['phone'];
				$email = $_POST['email'];
				$message = $_POST['message'];

				$to = 'mathewhaiyala@gmail.com';
				$subject = 'New Contact Form Submission';
				$email_message = "Name: $name\nPhone: $phone\nEmail: $email\n\n$message";

				mail($to, $subject, $email_message);

				echo '<script>alert("Thank you for contacting us. We will get back to you soon.");</script>';
			}
			?>